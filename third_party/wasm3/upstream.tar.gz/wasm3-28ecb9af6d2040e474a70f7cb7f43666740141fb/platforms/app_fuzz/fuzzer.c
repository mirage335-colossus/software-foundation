//
//  Wasm3 - high performance WebAssembly interpreter written in C.
//
//  Copyright © 2019 Steven Massey, Volodymyr Shymanskyy.
//  All rights reserved.
//

#include <stdint.h>
#include <stddef.h>

#include "wasm3.h"
#include "m3_env.h"    // for IM3Runtime::memoryLimit

#define FATAL(...) __builtin_trap()

// A module may declare up to 4 GiB of linear memory, and wasm3 allocates the
// initial pages eagerly at load, so a handful of bytes can ask for more than
// the fuzzing engine allows and get killed as an OOM rather than exercising
// anything. Cap what is actually allocated: memory accesses and data segment
// loads are bounded by the allocated length, not the declared page count.
#define d_m3FuzzMemoryLimit  (4*1024*1024)

// A table element is a pointer, so 1M of them are 8 MiB on a 64-bit host: the same
// order as the memory budget, and far below what d_m3MaxSaneTableSize allows.
#define d_m3FuzzTableLimit   (1024*1024)

// Nothing stops a few fuzzed bytes from describing a loop that never ends.
// Fuzzer timeout is an error => let's use gas metering to limit the number
// of instructions that can run.
#define d_m3FuzzGasLimit     (1000 * M3_GAS_UNITS_PER_GAS)

// Each active continuation holds a value stack of 8 KiB, so 256 of them are 2 MiB.
#define d_m3FuzzContinuationLimit  256

int LLVMFuzzerTestOneInput (const uint8_t* data, size_t size)
{
    M3Result result = m3Err_none;

    if (size < 8 || size > 256 * 1024) {
        return 0;
    }

    IM3Environment env = m3_NewEnvironment();
    if (env) {
        IM3Runtime runtime = m3_NewRuntime(env, 4096, NULL);
        if (runtime) {
            IM3Module module = NULL;

            runtime->memoryLimit = d_m3FuzzMemoryLimit;

            const struct {
                M3ResourceLimit limit;
                uint64_t        value;
            } limits[] = {
                { c_m3Limit_TableElements, d_m3FuzzTableLimit        },
                { c_m3Limit_GasUnits,      d_m3FuzzGasLimit          },
                { c_m3Limit_Continuations, d_m3FuzzContinuationLimit },
            };
            for (unsigned i = 0; i < sizeof(limits) / sizeof(limits[0]); ++i) {
                result = m3_SetResourceLimit(runtime, limits[i].limit, limits[i].value);
                if (result && result != m3Err_resourceLimitNotSupported) {
                    m3_FreeRuntime(runtime);
                    m3_FreeEnvironment(env);
                    return 0;
                }
            }

            result = m3_ParseModule(env, &module, data, size);
            if (module) {
                result = m3_LoadModule(runtime, module);
                if (result == 0) {
                    IM3Function f = NULL;

                    result = m3_FindFunction(&f, runtime, "fib");
                    if (f) {
                        if (m3_GetArgCount(f) == 1 && m3_GetArgType(f, 0) == c_m3Type_i32) {
                            m3_CallV(f, 10);
                        } else if (m3_GetArgCount(f) == 0) {
                            m3_CallV(f);
                        }
                    }
                }
                // on failure too, the runtime owns the module now
            }

            m3_FreeRuntime(runtime);
        }
        m3_FreeEnvironment(env);
    }

    return 0;
}
